from django.apps import AppConfig


class GameReviewsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "GameLounge.game_reviews"
